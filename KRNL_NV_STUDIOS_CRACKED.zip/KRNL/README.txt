SYNAPSE_X_CRACKED.EXE


CRACKED BY NV STUDIOS


The ".pbi" files use PureBasic Macros to insert the protection macros.

The ".pb" files use PureBasic Functions to insert the protection macros.

We recommend that you include the ".pbi" files instead of the ".pb" files. If your protection macros, 
via the ".pbi" file, are not recognized you can try with the ".pb" file instead.


Spring Boot 1.5.1.RELEASE
Custom: Exceptions, File IO, Rest Authentication
Spring Boot Test
JSON Library(javax.json)
Swagger API
Hibernate Validation API (org.hibernate)
Random Numbers and String Generators(smt-random-strings and smt-random-numbers)